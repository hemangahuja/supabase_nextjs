import React from 'react';
import Login from './pages/Login';
import Landing from './pages/Landing';
import Testinput from './pages/Testinput';
export default function App() {
  return (
    <>
      <Landing />
    </>
  );
}
